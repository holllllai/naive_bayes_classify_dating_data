This document explains how to run the code. 

reading and saving the data:
you should change data directories when reading the data and saving the data (for example: after saving preprocessed data to a file called dating-full.csv, you should change the output file destination to your own directory. )

some files include code that generates graphs and saves graphs to your local disk. If you don't want to save the graphs, comment out that section and use plt.show() instead. 

